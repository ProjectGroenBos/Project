﻿namespace ProjectGroenBos.Recreatie.Helper
{
    public class HelperClass
    {
        public static string DatabaseConnectieString = "Data Source=SQL.BIM.OSOX.NL;Initial Catalog=2020-BIM02-P1-P2-Groenbos;Persist Security Info=True;User ID=BIM022020;Password=BiM@IH2020";
    }
}