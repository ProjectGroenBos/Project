﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProjectGroenBos.Reservering
{
    public partial class Uitchecken : System.Web.UI.Page
    {
        int reserveringsnummer;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnZoek_Click(object sender, EventArgs e)
        {
            GridView1.Visible = false;
            GridView2.Visible = true;
            GridView2.DataBind();
        }
    }
}